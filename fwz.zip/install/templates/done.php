﻿<h3>Fertig</h3>

<p>Installation abgeschlossen! <b>Aus Sicherheitsgründen solltest du den Ordner "install" jetzt löschen.</b></p>

<hr>
<p>Du kannst dich jetzt in der Einsatzdokumentation oder im Adminbereich mit den folgenden Login Daten anmelden</p>

<ul>
	<li>Benutzer: <b>admin</b></li>
	<li>Passwort: <b>admin</b></li>
</ul>

<p>Erstelle als nächstes einen neuen Benutzer oder ändere das Standard Kennwort.<br />
<a href="index.php" class="button">Admin Login</a></p>

﻿<h3>Datei Berechtigungen</h3>

<?php if (!$goToNextStep) { ?>
	<div class="error">Unzureichende Dateiberechtigungen! Bitte überprüfe die chmod Berechtigungen.</div>
<?php } ?>

<table>
	<thead>
		<tr>
			<th>Name</th>
			<th>Real Path</th>
			<th>Benötigt</th>
			<th>Status</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($showPermissions as $filename => $permissions): ?>
		<tr>
			<td><?php echo $filename; ?></td>
			<td><?php echo $permissions['realpath']; ?></td>
			<td><?php echo $permissions['showRequired']; ?></td>
			<td><?php if ($permissions['error'] == "") { ?><img src="img/icons/accept.png"> OK <?php } else { ?><img src="img/icons/cancel.png"><?php echo $permissions['error']; ?> <?php } ?></td>
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>
<hr>


<a href="index.php" class="button negative">
	<img src="css/blueprint/plugins/buttons/icons/cross.png" alt=""/> Abbrechen
</a>

<?php if ($goToNextStep) { ?>
<form method="post">
	<input type="hidden" name="nextStep" value="database">
	<button type="submit" class="button positive">
		<img src="css/blueprint/plugins/buttons/icons/tick.png" alt=""/> Weiter
	</button>
</form>
<?php } else { ?>
	<form method="post">
		<input type="hidden" name="nextStep" value="filePermissions">
		<button type="submit" class="button positive">
			<img src="css/blueprint/plugins/buttons/icons/tick.png" alt=""/> Wiederholen
		</button>
	</form>
<?php } ?>
		</div>
		<hr>
	  
	  	<div class="span-24">
			Copyright 2018 <a href="http://www.dr-creative.de">Daniel Richter</a>
		</div>
	</div>
	
	<!-- Piwik -->
	
	
	
  </body>
</html>

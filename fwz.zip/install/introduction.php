<?php

	foreach ($introduction as $key => $value)
		$$key = $value;
		
	include("templates/introduction.php");
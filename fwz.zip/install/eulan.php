<?php
	$eula = file_get_contents("config/eula.txt");
	
	include("templates/eula.php");
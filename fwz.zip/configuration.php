<?php

class DATABASE_CONFIG
{
	var $dbconfig = array(
		'driver' => 'mysqli',
		'persistent' => false,
		'host' => 'localhost',
		'login' => 'fwz',
		'password' => 'rdfdghjhRy0?94',
		'database' => 'fwz_',
		'praefix' => 'ed_',
    'installed' => '1',
	);
  
}

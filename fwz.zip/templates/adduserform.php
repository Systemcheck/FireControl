<form>
  <div class="row">
    <div class="col">
      <input type="text" class="form-control" placeholder="Benutzername" required>
    </div>
    <div class="col">
      <input type="text" class="form-control" placeholder="Passwort">
    </div>
  </div>
  <div class="row">
    <div class="col">
      <input type="text" class="form-control" placeholder="Benutzername" required>
    </div>
    <div class="col">
      <input type="text" class="form-control" placeholder="Passwort">
    </div>
  </div>
</form>